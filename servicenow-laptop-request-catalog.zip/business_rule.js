// Business Rule (Before Insert) - Auto-set manager_approval to false
// Table: sc_request
(function execute(current, previous /*null when async*/) {
  // Default: manager_approval false (needs manager workflow)
  if (current.manager_approval == undefined || current.manager_approval == '') {
    current.manager_approval = false;
  }
})(current, previous);

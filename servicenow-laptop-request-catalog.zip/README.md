# ServiceNow – Laptop Request Catalog Item

Project: servicenow-laptop-request-catalog

Description:
A simple ServiceNow Catalog Item for employees to request a laptop. This repository contains example scripts and instructions to help you import or recreate the item in a ServiceNow instance.

Contents:
- README.md: Project overview and instructions.
- catalog_item.json: A template JSON outlining the catalog item fields.
- client_script.js: Example Catalog Client Script (onLoad).
- business_rule.js: Example Business Rule to auto-populate requester manager.
- workflow_notes.txt: Notes on a simple approval workflow.

How to use:
1. Create a new Catalog Item in your ServiceNow instance (Service Catalog > Catalog Definitions > Maintain Items).
2. Add fields: laptop_type, ram, storage, justification, manager_approval.
3. Paste the client_script.js into a Catalog Client Script (Type: onLoad).
4. Create a business rule or script include if you want server-side logic.
5. Optionally recreate the workflow described in workflow_notes.txt.

License: MIT

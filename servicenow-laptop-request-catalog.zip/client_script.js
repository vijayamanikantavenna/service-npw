// Catalog Client Script (onLoad)
function onLoad() {
  // Make justification mandatory if Budget laptop selected
  var lt = g_form.getValue('laptop_type');
  if (lt == 'Budget') {
    g_form.setMandatory('justification', true);
    g_form.addInfoMessage('Justification is required for Budget laptops.');
  } else {
    g_form.setMandatory('justification', false);
    g_form.clearMessages();
  }
}

// Catalog Client Script (onChange for laptop_type)
function onChange(control, oldValue, newValue, isLoading) {
  if (isLoading) return;
  if (newValue == 'Budget') {
    g_form.setMandatory('justification', true);
  } else {
    g_form.setMandatory('justification', false);
  }
}
